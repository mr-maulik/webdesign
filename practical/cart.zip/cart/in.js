var inp = parseInt(document.getElementById('inp').value);

        function addValue() {
            inp += 1;
            document.getElementById('inp').value = inp;
            console.log(inp);
        }