function removeClass() {
    var barList = document.getElementById("bar");
    barList.style.display = "none";
}
function addClass(){
    var barList = document.getElementById("bar");
    barList.style.display = "block";
}

function rotetBox(){
    var boxRound = document.getElementsByClassName("itm");
    boxRound.style
}




