var barList = document.getElementById("bar");

function removeClass() {
    var barList = document.getElementById("bar");
    barList.style.display = "none";
}
function addClass(){
    var barList = document.getElementById("bar");
    barList.style.display = "block";
}






